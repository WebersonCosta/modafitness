import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

// COMPONENTS
import Navbar from './components/Navbar/Navbar';
import Footer from './components/Footer/Footer';
import PrivateRoute from './components/PrivateRoute';

// PAGES
import Home from './pages/Home/Home';
import Masculino from './pages/Produtos/Masculino/Masculino';
import Feminino from './pages/Produtos/Feminino/Feminino';
import Colecao from './pages/Produtos/Colecoes/Colecoes';
import Login from './pages/Admin/Login';
import Dashboard from './pages/Admin/Dashboard';

const App = () => {
  return (
    <Router>
      <Navbar />
      <Routes>
        {/* Rota pública */}
        <Route path="/" element={<Home />} />
        <Route path="/produtos/masculino" element={<Masculino />} />
        <Route path="/produtos/feminino" element={<Feminino />} />
        <Route path="/produtos/colecao" element={<Colecao />} />

        <Route path="/admin/login" element={<Login />} />
        {/* Rota protegida */}
        <Route
          path="/admin/dashboard"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        />
      </Routes>
      <Footer />
    </Router>
  );
};
export default App;
