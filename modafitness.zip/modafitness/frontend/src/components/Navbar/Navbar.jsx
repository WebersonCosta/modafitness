import React, { useState } from 'react';
import { FiSearch, FiShoppingCart, FiMenu, FiX } from 'react-icons/fi';
import { useMediaQuery } from 'react-responsive'; // Certifique-se de que está importando corretamente
import clsx from 'clsx';
import styles from './Navbar.module.scss';
import Main from '../Main/Main';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  // Corrige a consulta de mídia
  const isMobile = useMediaQuery({ query: '(max-width: 768px)' });
  //console.log(isMobile);
  const toggleMenu = () => setMenuOpen(!menuOpen);

  const handleLinkClick = () => {
    setMenuOpen(false);
  };

  return (
    <>
      <nav className={styles.navbar}>
        <Main>
          <div className={styles.navbarContent}>
            {/* Logo */}
            <div className={styles.logo}>Store</div>

            {/* Desktop Links */}
            {!isMobile && (
              <ul className={styles.navLinks}>
                <li>
                  <Link to="/">Home</Link>
                </li>
                <li>
                  <Link to="/produtos/masculino">Masculino</Link>
                </li>
                <li>
                  <Link to="/produtos/feminino">Feminino</Link>
                </li>
                <li>
                  <Link to="/produtos/colecao">Coleções</Link>
                </li>
              </ul>
            )}

            {/* Desktop Search */}
            {!isMobile && (
              <div className={styles.search}>
                <input
                  type="text"
                  placeholder="Buscar produtos..."
                  aria-label="Campo de pesquisa"
                />
                <button className={styles.searchButton} aria-label="Pesquisar">
                  <FiSearch />
                </button>
              </div>
            )}

            {/* Carrinho e Menu */}
            <div className={styles.icons}>
              <FiShoppingCart className={styles.icon} />
              {isMobile && (
                <button
                  className={styles.menuButton}
                  onClick={toggleMenu}
                  aria-label="Abrir menu"
                >
                  {menuOpen ? (
                    <FiX className={styles.icon} />
                  ) : (
                    <FiMenu className={styles.icon} />
                  )}
                </button>
              )}
            </div>

            {/* Mobile Menu */}
            {isMobile && (
              <div
                className={clsx(styles.mobileMenu, { [styles.open]: menuOpen })}
              >
                {console.log('Menu Open', menuOpen)}
                <ul className={styles.navLinks}>
                  <li>
                    <Link to="/" onClick={handleLinkClick}>
                      Home
                    </Link>
                  </li>
                  <li>
                    <Link to="/produtos/masculino" onClick={handleLinkClick}>
                      Masculino
                    </Link>
                  </li>
                  <li>
                    <Link to="/produtos/feminino" onClick={handleLinkClick}>
                      Feminino
                    </Link>
                  </li>
                  <li>
                    <Link to="/produtos/colecao" onClick={handleLinkClick}>
                      Coleções
                    </Link>
                  </li>
                </ul>
                <div className={styles.search}>
                  <div>
                    <input
                      type="text"
                      placeholder="Buscar produtos..."
                      aria-label="Campo de pesquisa"
                    />
                    <button
                      className={styles.searchButton}
                      aria-label="Pesquisar"
                    >
                      <FiSearch />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </Main>
      </nav>
    </>
  );
};

export default Navbar;
