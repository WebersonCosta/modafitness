import React from 'react';
import { FiFacebook, FiInstagram, FiTwitter } from 'react-icons/fi';
import styles from './Footer.module.scss';
import Main from '../Main/Main';

const Footer = () => (
  <footer className={styles.footer}>
    <Main>
      <div className={styles.container}>
        {/* Navegação */}
        <div className={styles.navSection}>
          <ul>
            <li>Sobre Nós</li>
            <li>Contato</li>
            <li>Política de Privacidade</li>
            <li>Termos de Serviço</li>
          </ul>
        </div>

        {/* Redes Sociais */}
        <div className={styles.socialSection}>
          <span>Siga-nos:</span>
          <div className={styles.icons}>
            <FiFacebook />
            <FiInstagram />
            <FiTwitter />
          </div>
        </div>

        {/* Direitos Autorais */}
        <div className={styles.copyright}>
          &copy; {new Date().getFullYear()} Fitness Store. Todos os direitos
          reservados.
        </div>
      </div>
    </Main>
  </footer>
);

export default Footer;
