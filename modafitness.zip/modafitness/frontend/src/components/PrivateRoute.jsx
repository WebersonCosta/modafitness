// src/components/PrivateRoute.js
import React from 'react';
import { Navigate } from 'react-router-dom';
import useAuthStore from '../store/authStore';

const PrivateRoute = ({ children }) => {
  const { isAuthenticated } = useAuthStore();

  // Se não estiver autenticado, redireciona para a página de login
  return isAuthenticated ? children : <Navigate to="/admin/login" />;
};

export default PrivateRoute;
