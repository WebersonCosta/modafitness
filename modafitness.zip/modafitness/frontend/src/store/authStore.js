// src/store/authStore.js

import { create } from 'zustand';

const useAuthStore = create((set) => ({
  isAuthenticated: false,
  user: null, // Armazenando o usuário autenticado (se necessário)
  login: (user) => set({ isAuthenticated: true, user }), // Fazendo login e armazenando o usuário
  logout: () => set({ isAuthenticated: false, user: null }), // Fazendo logout e limpando o usuário
}));

export default useAuthStore;
