import { FiSearch } from 'react-icons/fi';
import styles from './SearchField.module.scss';

const SearchField = () => {
  return (
    <div className={styles.search}>
      <input
        type="text"
        placeholder="Buscar produtos..."
        aria-label="Campo de pesquisa"
      />
      <button className={styles.searchButton} aria-label="Pesquisar">
        <FiSearch />
      </button>
    </div>
  );
};

export default SearchField;
