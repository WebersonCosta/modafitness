import React, { useState } from 'react';
import { FiBell, FiMenu, FiX, FiUser } from 'react-icons/fi';
import { useMediaQuery } from 'react-responsive';
import clsx from 'clsx';
import styles from './DashboardHeader.module.scss';
import { Link } from 'react-router-dom';
import SearchField from '../SearchField/SearchField';

const DashboardHeader = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  // Detecta a versão mobile ou desktop
  const isMobile = useMediaQuery({ query: '(max-width: 768px)' });

  const toggleMenu = () => setMenuOpen(!menuOpen);
  const handleLinkClick = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.headerContent}>
        {/* Logo */}
        <div className={styles.logo}>
          <Link to="/">Store</Link>
        </div>

        {/* Versão Desktop */}
        {!isMobile && (
          <>
            {/* Barra de busca */}
            <SearchField className={styles.search} />

            {/* Ícones Desktop (Notificação, Usuário) */}
            <div className={styles.icons}>
              <FiBell className={styles.icon} />
              <FiUser className={styles.icon} />
            </div>
          </>
        )}
      </div>

      {/* Menu Mobile */}
    </header>
  );
};

export default DashboardHeader;
