import create from 'zustand';

const useStore = create((set) => ({
  products: [],
  orders: [],
  setProducts: (products) => set({ products }),
  setOrders: (orders) => set({ orders }),
}));

export default useStore;
