import React from 'react';
import Main from '../../../components/Main/Main';

const Masculino = () => {
  return (
    <>
      <Main>
        <div>
          <h1>Masculino</h1>
          <p>Confira nossa coleção masculina.</p>
        </div>
      </Main>
    </>
  );
};

export default Masculino;
