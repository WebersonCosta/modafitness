import React from 'react';
import Main from '../../../components/Main/Main';

const Colecao = () => {
  return (
    <>
      <Main>
        <div>
          <h1>Coleções</h1>
          <p>Descubra nossas coleções exclusivas.</p>
        </div>
      </Main>
    </>
  );
};

export default Colecao;
