import React from 'react';
import Main from '../../../components/Main/Main';

const Feminino = () => {
  return (
    <>
      <Main>
        <div>
          <h1>Feminino</h1>
          <p>Explore a nossa coleção feminina.</p>
        </div>
      </Main>
    </>
  );
};

export default Feminino;
