// src/pages/AdminDashboard.js
import React from 'react';
import DashboardHeader from '../../../components/DashboardHeader/DashboardHeader';

const AdminDashboard = () => {
  return (
    <div>
      <DashboardHeader />
      <h2>Dashboard do Administrador</h2>
      <p>Bem-vindo ao painel administrativo.</p>
      {/* Adicione funcionalidades exclusivas do administrador aqui */}
    </div>
  );
};

export default AdminDashboard;
