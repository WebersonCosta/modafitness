import React, { useEffect } from 'react';
import axios from 'axios';
import useStore from '../../../store/useStore';

const Products = () => {
  const { products, setProducts } = useStore();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get('/api/products');
        setProducts(response.data); // Armazena os produtos no Zustand
      } catch (error) {
        console.error('Erro ao carregar produtos', error);
      }
    };
    fetchProducts();
  }, [setProducts]);

  return (
    <div>
      <h1>Produtos</h1>
      <div>
        {products.map((product) => (
          <div key={product.id}>
            <h2>{product.name}</h2>
            <p>{product.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Products;
