// src/pages/Admin/Login.jsx
import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import useAuthStore from '../../../store/authStore';
import styles from './Login.module.scss';

const schema = yup
  .object({
    username: yup.string().required('Nome de usuário é obrigatório'),
    password: yup.string().required('Senha é obrigatória'),
  })
  .required();

const Login = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const { isAuthenticated, login } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => {
    // Se o usuário já estiver autenticado, redireciona para o dashboard
    if (isAuthenticated) {
      navigate('/admin/dashboard');
    }
  }, [isAuthenticated, navigate]);

  const onSubmit = (data) => {
    // Aqui você pode validar as credenciais
    if (data.username === 'admin' && data.password === 'admin123') {
      login();
      navigate('/admin/dashboard');
    } else {
      alert('Credenciais inválidas');
    }
  };

  return (
    <div className={styles['login-container']}>
      <div className={styles['login-form']}>
        <h2>Login de Administrador</h2>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className={styles['form-group']}>
            <label>Nome de Usuário</label>
            <input {...register('username')} />
            <p>{errors.username?.message}</p>
          </div>
          <div className={styles['form-group']}>
            <label>Senha</label>
            <input type="password" {...register('password')} />
            <p>{errors.password?.message}</p>
          </div>
          <button type="submit">Entrar</button>
        </form>
      </div>
    </div>
  );
};

export default Login;
