import React from 'react';
import Sidebar from '../components/Sidebar/Sidebar'; // Crie este componente

const AdminLayout = ({ children }) => {
  return (
    <div style={{ display: 'flex', height: '100%' }}>
      <Sidebar />
      <main style={{ flex: 1, padding: '20px' }}>{children}</main>
    </div>
  );
};

export default AdminLayout;
