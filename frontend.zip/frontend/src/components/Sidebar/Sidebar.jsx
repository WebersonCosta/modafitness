import React from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.module.scss'; // Use um arquivo de estilo para personalizar

const Sidebar = () => {
  return (
    <nav
      style={{
        width: '250px',
        background: '#1A202C',
        color: '#F7FAFC',
        height: '98vh',
      }}
    >
      <ul>
        <li>
          <Link
            to="/admin/dashboard"
            style={{ color: 'inherit', textDecoration: 'none' }}
          >
            Dashboard
          </Link>
        </li>
        {/* Adicione mais links conforme necessário */}
      </ul>
    </nav>
  );
};

export default Sidebar;
