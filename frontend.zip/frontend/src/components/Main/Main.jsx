import React from 'react';
import styles from './Main.module.scss';

const Main = (props) => {
  return (
    <main className={styles.content}>
      <div className={styles.mainSpace}>{props.children}</div>
    </main>
  );
};

export default Main;
