import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

// COMPONENTS
import PrivateRoute from './components/PrivateRoute';

// LAYOUTS
import PublicLayout from './layouts/PublicLayout';
import AdminLayout from './layouts/AdminLayout';

// PAGES
import Home from './pages/Home/Home';
import Masculino from './pages/Produtos/Masculino/Masculino';
import Feminino from './pages/Produtos/Feminino/Feminino';
import Colecao from './pages/Produtos/Colecoes/Colecoes';
import Login from './pages/Admin/Login';
import Dashboard from './pages/Admin/Dashboard';

const App = () => {
  return (
    <Router>
      <Routes>
        {/* Rotas públicas */}
        <Route
          path="/"
          element={
            <PublicLayout>
              <Home />
            </PublicLayout>
          }
        />
        <Route
          path="/produtos/masculino"
          element={
            <PublicLayout>
              <Masculino />
            </PublicLayout>
          }
        />
        <Route
          path="/produtos/feminino"
          element={
            <PublicLayout>
              <Feminino />
            </PublicLayout>
          }
        />
        <Route
          path="/produtos/colecao"
          element={
            <PublicLayout>
              <Colecao />
            </PublicLayout>
          }
        />
        <Route
          path="/admin/login"
          element={
            <PublicLayout>
              <Login />
            </PublicLayout>
          }
        />

        {/* Rotas do administrador */}
        <Route
          path="/admin/dashboard"
          element={
            <PrivateRoute>
              <AdminLayout>
                <Dashboard />
              </AdminLayout>
            </PrivateRoute>
          }
        />
      </Routes>
    </Router>
  );
};

export default App;
