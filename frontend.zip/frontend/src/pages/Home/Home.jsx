import React from 'react';
import styles from './Home.module.scss';
import Main from '../../components/Main/Main';

const Home = () => {
  return (
    <>
      <Main>
        <div className={styles.content}>
          <h1>Home</h1>
          <p>Bem-vindo(a) à loja de roupas fitness!</p>
        </div>
      </Main>
    </>
  );
};

export default Home;
