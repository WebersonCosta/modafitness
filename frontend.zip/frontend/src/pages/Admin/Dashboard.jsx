// src/pages/AdminDashboard.js
import React from 'react';

const AdminDashboard = () => {
  return (
    <div>
      <h2>Dashboard do Administrador</h2>
      <p>Bem-vindo ao painel administrativo.</p>
      {/* Adicione funcionalidades exclusivas do administrador aqui */}
    </div>
  );
};

export default AdminDashboard;
